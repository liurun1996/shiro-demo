$(document).ready(function(){
    setTimeout(function(){
    	window.history.back(-1);
    }, 5000);
})

#SpringBoot笔记  
[（一）SpringBoot基本操作——环境搭建及项目创建（有demo）](https://blog.csdn.net/zhulier1124/article/details/81988471)   
[（二）SpringBoot基本操作——使用IDEA打war包发布及测试](https://blog.csdn.net/zhulier1124/article/details/82012829)   
[（三）SpringBoot基本操作——SpringBoot整合SpringDataJpa（有demo）](https://blog.csdn.net/zhulier1124/article/details/82121461)   
[（四）SpringBoot基本操作——SpringBoot使用RedisTemplate整合Redis（有demo）](https://blog.csdn.net/zhulier1124/article/details/82154937)   
[（五）SpringBoot基本操作——SpringBoot使用Jedis整合Redis（有demo）](https://blog.csdn.net/zhulier1124/article/details/82193182)   
[（六）SpringBoot基本操作——SpringBoot使用Junit4单元测试（有demo）](https://blog.csdn.net/zhulier1124/article/details/82228831)   
[（七）SpringBoot基本操作——SpringBoot整合Shiro权限管理（完整demo+界面）](https://blog.csdn.net/zhulier1124/article/details/82289736)    


#项目结构  
SpringBoot2.0  
Thymeleaf3.0  
SpringDataJPA  
MySql  
Redis  
lombok  

#外部Tomcat启动测试
**必须加入项目包名**  

#联系方式
824247231